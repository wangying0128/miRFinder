#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned int Uint;
typedef unsigned long Ulong;

#endif
