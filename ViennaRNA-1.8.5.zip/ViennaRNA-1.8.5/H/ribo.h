extern float **get_ribosum(char *Alseq[], int n_seq, int length);
